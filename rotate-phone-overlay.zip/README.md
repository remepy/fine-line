# rotate-phone-overlay

A self-contained "please rotate your phone" overlay for React + TypeScript projects targeting mobile landscape-only experiences.

## Files

| File | Purpose |
|------|---------|
| `PortraitOverlay.tsx` | Full-screen animated overlay component |
| `useIsRotated.ts` | Hook that detects portrait orientation on touch devices |
| `portrait-overlay.css` | Styles for the overlay |

## Requirements

- React 17+ (uses hooks)
- TypeScript (or strip the types and rename to `.jsx` / `.js`)

## Usage

1. Copy all four files into your project (e.g. `src/components/`).
2. Import and use:

```tsx
import { useIsRotated } from "./useIsRotated";
import { PortraitOverlay } from "./PortraitOverlay";
import "./portrait-overlay.css";

export function App() {
  const isPortrait = useIsRotated();

  return (
    <>
      <PortraitOverlay visible={isPortrait} />
      {/* rest of your app */}
    </>
  );
}
```

## Props

### `<PortraitOverlay>`

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `visible` | `boolean` | required | Show/hide the overlay |
| `message` | `string` | `"סובבו את הטלפון למצב מאוזן"` | Text shown below the animation. Replace with your own language, e.g. `"Please rotate your phone"` |

## Theming

The CSS uses three hard-coded colour values. Override them with your own CSS variables or values by editing `portrait-overlay.css`:

| CSS rule | Default value | What it controls |
|----------|--------------|-----------------|
| `.portrait-overlay { background }` | `#1a1a2e` | Overlay background |
| `.portrait-overlay__icon { color }` | `#f59e0b` | Animated phone icon colour |
| `.portrait-overlay__text { color }` | `#ffffff` | Message text colour |

Or use your project's CSS variables:

```css
.portrait-overlay        { background: var(--your-bg); }
.portrait-overlay__icon  { color: var(--your-accent); }
.portrait-overlay__text  { color: var(--your-text); }
```

## Behaviour

- Activates on touch-capable browsers when the layout viewport is portrait (including touch-enabled laptops).
- Uses the CSS orientation media query rather than trusting screen.orientation.type, which can disagree with the page layout.
- Rechecks after rotation, viewport resize, and page restoration, including delayed checks while the layout settles.
- Does not bypass iPhone Portrait Orientation Lock or force the browser to rotate. If the page remains portrait, turn off that lock in Control Center.
- English messages can use an override: `.portrait-overlay__text { direction: ltr; }`.
